-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 05:20 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pora`
--

-- --------------------------------------------------------

--
-- Table structure for table `addpatient`
--

CREATE TABLE `addpatient` (
  `s_no` int(11) NOT NULL,
  `Patient_id` varchar(100) DEFAULT NULL,
  `Name` varchar(255) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `DOB` varchar(20) DEFAULT NULL,
  `Mobile_no` varchar(20) DEFAULT NULL,
  `Diagnosis` varchar(255) DEFAULT NULL,
  `Surgery_planned` varchar(10) DEFAULT NULL,
  `problem` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addpatient`
--

INSERT INTO `addpatient` (`s_no`, `Patient_id`, `Name`, `Age`, `DOB`, `Mobile_no`, `Diagnosis`, `Surgery_planned`, `problem`) VALUES
(53, '454545', 'gfhhgh', 30, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(54, '', 'AK', 30, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(55, '12121', 'Kiruba', 22, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(56, 'jkjkhh', 'AK', 30, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(57, '8768', 'AKgghh', 30, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(58, '24674', 'AKadgff', 30, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(59, '345', 'AKc bbvv', 30, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(60, '466565', 'AK', 30, '20-20-2222', '6464684646', 'NAS', 'JKSFd', 'dfg'),
(61, '10090', 'mani', 30, '20-20-2222', '9898767534', 'Nil', '0', 'nil'),
(62, '7777', 'kavin kumar7', 30, '20-20-2222', '9898767534', 'Nil', '0', 'nil'),
(63, '1232', 'kavin kumar', 30, '20-20-2222', '9898767534', 'Nil', '0', 'nil'),
(64, '1234567', 'kiruba', 23, '26-01-2001', '9876543210', 'lungs', '2', 'kidney');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `s_no` int(11) NOT NULL,
  `Patient_id` int(50) NOT NULL,
  `subdivision_id` int(11) NOT NULL,
  `subdivision_text` varchar(255) NOT NULL,
  `main_question_id` int(11) NOT NULL,
  `main_question_text` varchar(255) NOT NULL,
  `answer` varchar(255) DEFAULT NULL,
  `score_value` varchar(100) NOT NULL,
  `question` varchar(255) DEFAULT NULL,
  `grand_total_score` int(255) NOT NULL,
  `comment_box` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`s_no`, `Patient_id`, `subdivision_id`, `subdivision_text`, `main_question_id`, `main_question_text`, `answer`, `score_value`, `question`, `grand_total_score`, `comment_box`) VALUES
(1140, 454545, 101, '', 1, '', 'Adult', '1', '1. Age', 62, ''),
(1141, 454545, 101, '', 1, '', '>=40', '4', '2. BMI', 62, ''),
(1142, 454545, 101, '', 1, '', 'Low Risk (0 - 2)', '0', '3. Stop Bang Score', 62, ''),
(1143, 454545, 101, '', 1, '', 'Both', '2', '4. Personal History', 62, ''),
(1144, 454545, 101, '', 1, '', '>2', '3', '5. No of Previous Surgeries Under Anesthesia', 62, ''),
(1145, 454545, 101, '', 1, '', 'Hypo/Hyperthyroidism', '1', '6. Comorbidities', 62, ''),
(1146, 454545, 101, '', 1, '', 'Allergy to Food', '1', '7. Allergy History ', 62, ''),
(1147, 454545, 101, '', 1, '', 'U Unconscious', '3', '8. Mental Status', 62, ''),
(1148, 454545, 101, '', 1, '', 'Minor', '1', '9. Types of Surgery', 62, 'Add Your Comments...'),
(1149, 454545, 102, '', 1, '', '<2Fingers', '2', '2.1 Inter Incisor Gap (IIG)', 62, ''),
(1150, 454545, 102, '', 1, '', '3 And 4', '2', '2.2 Modified Mallam Patti Scale (MMP)', 62, ''),
(1151, 454545, 102, '', 1, '', '<3 Fingers wide', '2', '2.3 Thyromental Distance', 62, ''),
(1152, 454545, 102, '', 1, '', 'Severe Restriction', '3', '2.4 Neck Movement', 62, ''),
(1153, 454545, 102, '', 1, '', 'Class 3', '2', '2.5 Upper Lip Bite Test', 62, ''),
(1154, 454545, 102, '', 1, '', 'Snoring', '1', '2.6 BONES', 62, ''),
(1155, 454545, 102, '', 1, '', 'Snoring/Stiff Lungs', '1', '2.7 MOANS', 62, ''),
(1156, 454545, 102, '', 1, '', 'Stiff Lungs', '1', '2.8 RODS', 62, ''),
(1157, 454545, 102, '', 1, '', 'Tumor', '1', '2.9 SHORT', 62, ''),
(1158, 454545, 102, '', 1, '', 'Neck Mobility', '1', '2.9.1 LEMON', 62, 'Add Your Comments...'),
(1159, 454545, 103, '', 1, '', 'NYHA Grade 4', '1', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 62, ''),
(1160, 454545, 103, '', 1, '', 'Severe Restriction or Obstruction', '3', '3.2 Respiratory System (Pulmonary Function Test)', 62, ''),
(1161, 454545, 103, '', 1, '', 'EGFR <15', '5', '3.3 RENAL ', 62, ''),
(1162, 454545, 103, '', 1, '', '>40', '3', '3.4 Respiratory Rate', 62, ''),
(1163, 454545, 103, '', 1, '', '92 - 100 with Ventilatory Support', '3', '3.5 SPO2', 62, ''),
(1164, 454545, 103, '', 1, '', 'Grade 3 Hypertension (SPB > 180 and/or DPB >180)', '4', '3.6 Blood Pressure', 62, ''),
(1165, 454545, 103, '', 1, '', '<6', '4', '3.7 Hemoglobin', 62, ''),
(1166, 454545, 103, '', 1, '', '>160', '4', '3.8 Heart Rate', 62, ''),
(1167, 454545, 103, '', 1, '', '<10', '3', '3.9 Breath Holding', 62, 'Add Your Comments...'),
(1168, 454545, 104, '', 2, '', 'More than 30', '3', '4.1 Peak Airways Pressure', 18, ''),
(1169, 454545, 104, '', 2, '', 'Anuria', '3', '4.2 Urine Output', 18, ''),
(1170, 454545, 104, '', 2, '', '>2000ML', '4', '4.3 Blood Loss', 18, ''),
(1171, 454545, 104, '', 2, '', 'NO', '2', '4.4 Blood Transfusion', 18, ''),
(1172, 454545, 104, '', 2, '', '3 Inotropes', '4', '4.5 Need For Inotropes', 18, ''),
(1173, 454545, 104, '', 2, '', 'Not Given', '2', '4.6 Antibiotic', 18, 'Add Your Comments...'),
(1174, 454545, 105, '', 3, '', 'Need For Ventilator', '3', '5.1 Oxygen Requirements', 35, ''),
(1175, 454545, 105, '', 3, '', 'WARD', '1', '5.2 ICU/WARD', 35, ''),
(1176, 454545, 105, '', 3, '', '>160', '4', '5.3 Heart Rate', 35, ''),
(1177, 454545, 105, '', 3, '', '>40', '3', '5.4 Respiratory Rate', 35, ''),
(1178, 454545, 105, '', 3, '', '92 - 100 with Ventilatory Support', '3', '5.5 SPO2', 35, ''),
(1179, 454545, 105, '', 3, '', 'Grade 3 Hypertension (SPB > 180 and/or DPB >180)', '4', '5.6 Blood Pressure', 35, ''),
(1180, 454545, 105, '', 3, '', '<6', '4', '5.7 Hemoglobin', 35, ''),
(1181, 454545, 105, '', 3, '', 'Score 5 and 6', '4', '5.8 Modified Ramsay Sedation Score', 35, ''),
(1182, 454545, 105, '', 3, '', '8 - 10', '4', '5.9 Vas Score', 35, ''),
(1183, 454545, 105, '', 3, '', 'Severe', '2', '5.9.1 PONV', 35, ''),
(1184, 454545, 105, '', 3, '', '3(Severe)', '3', '5.9.2 Shivering Scale', 35, 'Add Your Comments...'),
(1185, 3443, 101, '', 1, '', 'Both', '3', '1 Personal History', 3, ''),
(1186, 12121, 101, '', 1, '', 'Adult', '1', '1. Age', 32, ''),
(1187, 12121, 101, '', 1, '', '>=40', '4', '2. BMI', 32, ''),
(1188, 12121, 101, '', 1, '', 'Intermediate Risk (3 - 4)', '1', '3. Stop Bang Score', 32, ''),
(1189, 12121, 101, '', 1, '', 'Both', '2', '4. Personal History', 32, ''),
(1190, 12121, 101, '', 1, '', '>2', '3', '5. No of Previous Surgeries Under Anesthesia', 32, ''),
(1191, 12121, 101, '', 1, '', 'Hypo/Hyperthyroidism', '1', '6. Comorbidities', 32, ''),
(1192, 12121, 101, '', 1, '', 'Allergy to Food', '1', '7. Allergy History ', 32, ''),
(1193, 12121, 101, '', 1, '', 'U Unconscious', '3', '8. Mental Status', 32, ''),
(1194, 12121, 101, '', 1, '', 'Minor', '1', '9. Types of Surgery', 32, 'Add Your Comments...'),
(1195, 12121, 102, '', 1, '', '<2Fingers', '2', '2.1 Inter Incisor Gap (IIG)', 32, ''),
(1196, 12121, 102, '', 1, '', '3 And 4', '2', '2.2 Modified Mallam Patti Scale (MMP)', 32, ''),
(1197, 12121, 102, '', 1, '', '<3 Fingers wide', '2', '2.3 Thyromental Distance', 32, ''),
(1198, 12121, 102, '', 1, '', 'Severe Restriction', '3', '2.4 Neck Movement', 32, ''),
(1199, 12121, 102, '', 1, '', 'Class 1', '0', '2.5 Upper Lip Bite Test', 32, ''),
(1200, 12121, 102, '', 1, '', 'Beard ', '1', '2.6 BONES', 32, ''),
(1201, 12121, 102, '', 1, '', 'Snoring/Stiff Lungs', '1', '2.7 MOANS', 32, ''),
(1202, 12121, 102, '', 1, '', 'Stiff Lungs', '1', '2.8 RODS', 32, ''),
(1203, 12121, 102, '', 1, '', 'Tumor', '1', '2.9 SHORT', 32, ''),
(1204, 12121, 102, '', 1, '', 'Look Externally', '1', '2.9.1 LEMON', 32, 'Add Your Comments...'),
(1205, 12121, 103, '', 1, '', 'NIL ', '1', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 32, ''),
(1206, 12121, 103, '', 1, '', 'No Restriction', '0', '3.2 Respiratory System (Pulmonary Function Test)', 32, ''),
(1207, 12121, 103, '', 1, '', 'EGFR >90', '0', '3.3 RENAL ', 32, ''),
(1208, 12121, 103, '', 1, '', '12 - 24', '0', '3.4 Respiratory Rate', 32, ''),
(1209, 12121, 103, '', 1, '', '92 - 100 at RA', '0', '3.5 SPO2', 32, ''),
(1210, 12121, 103, '', 1, '', 'Optimal (SPB<120 and DPB<80)', '0', '3.6 Blood Pressure', 32, ''),
(1211, 12121, 103, '', 1, '', '12 - 16 mg/dl.', '0', '3.7 Hemoglobin', 32, ''),
(1212, 12121, 103, '', 1, '', '60 - 100', '0', '3.8 Heart Rate', 32, ''),
(1213, 12121, 103, '', 1, '', '>25', '0', '3.9 Breath Holding', 32, 'Add Your Comments...'),
(1214, 12121, 104, '', 2, '', 'More than 30', '3', '4.1 Peak Airways Pressure', 18, ''),
(1215, 12121, 104, '', 2, '', 'Anuria', '3', '4.2 Urine Output', 18, ''),
(1216, 12121, 104, '', 2, '', '>2000ML', '4', '4.3 Blood Loss', 18, ''),
(1217, 12121, 104, '', 2, '', 'NO', '2', '4.4 Blood Transfusion', 18, ''),
(1218, 12121, 104, '', 2, '', '3 Inotropes', '4', '4.5 Need For Inotropes', 18, ''),
(1219, 12121, 104, '', 2, '', 'Not Given', '2', '4.6 Antibiotic', 18, 'Add Your Comments...'),
(1220, 12121, 105, '', 3, '', 'Need For Ventilator', '3', '5.1 Oxygen Requirements', 35, ''),
(1221, 12121, 105, '', 3, '', 'WARD', '1', '5.2 ICU/WARD', 35, ''),
(1222, 12121, 105, '', 3, '', '>160', '4', '5.3 Heart Rate', 35, ''),
(1223, 12121, 105, '', 3, '', '>40', '3', '5.4 Respiratory Rate', 35, ''),
(1224, 12121, 105, '', 3, '', '92 - 100 with Ventilatory Support', '3', '5.5 SPO2', 35, ''),
(1225, 12121, 105, '', 3, '', 'Grade 3 Hypertension (SPB > 180 and/or DPB >180)', '4', '5.6 Blood Pressure', 35, ''),
(1226, 12121, 105, '', 3, '', '<6', '4', '5.7 Hemoglobin', 35, ''),
(1227, 12121, 105, '', 3, '', 'Score 5 and 6', '4', '5.8 Modified Ramsay Sedation Score', 35, ''),
(1228, 12121, 105, '', 3, '', '8 - 10', '4', '5.9 Vas Score', 35, ''),
(1229, 12121, 105, '', 3, '', 'Severe', '2', '5.9.1 PONV', 35, ''),
(1230, 12121, 105, '', 3, '', '3(Severe)', '3', '5.9.2 Shivering Scale', 35, 'Add Your Comments...'),
(1231, 466565, 101, '', 1, '', 'Pediatric/Elderly', '2', '1. Age', 38, ''),
(1232, 466565, 101, '', 1, '', '35 - 39.9', '3', '2. BMI', 38, ''),
(1233, 466565, 101, '', 1, '', 'High Risk (5 - 8)', '2', '3. Stop Bang Score', 38, ''),
(1234, 466565, 101, '', 1, '', 'Alcoholic', '1', '4. Personal History', 38, ''),
(1235, 466565, 101, '', 1, '', '1', '1', '5. No of Previous Surgeries Under Anesthesia', 38, ''),
(1236, 466565, 101, '', 1, '', 'Diabetic', '1', '6. Comorbidities', 38, ''),
(1237, 466565, 101, '', 1, '', 'Allergy to Drugs', '1', '7. Allergy History ', 38, ''),
(1238, 466565, 101, '', 1, '', 'P Pain', '2', '8. Mental Status', 38, ''),
(1239, 466565, 101, '', 1, '', 'Intermediate', '2', '9. Types of Surgery', 38, 'Add Your Comments...'),
(1240, 466565, 102, '', 1, '', '2 -3 Fingers', '1', '2.1 Inter Incisor Gap (IIG)', 38, ''),
(1241, 466565, 102, '', 1, '', '2', '1', '2.2 Modified Mallam Patti Scale (MMP)', 38, ''),
(1242, 466565, 102, '', 1, '', '4 - 3 Fingers Wide', '1', '2.3 Thyromental Distance', 38, ''),
(1243, 466565, 102, '', 1, '', 'Mild Restriction', '1', '2.4 Neck Movement', 38, ''),
(1244, 466565, 102, '', 1, '', 'Class 2', '1', '2.5 Upper Lip Bite Test', 38, ''),
(1245, 466565, 102, '', 1, '', 'Obesity', '1', '2.6 BONES', 38, ''),
(1246, 466565, 102, '', 1, '', 'Age', '1', '2.7 MOANS', 38, ''),
(1247, 466565, 102, '', 1, '', 'Disrupted/Distorted Airways', '1', '2.8 RODS', 38, ''),
(1248, 466565, 102, '', 1, '', 'Radiation Distortion', '1', '2.9 SHORT', 38, ''),
(1249, 466565, 102, '', 1, '', 'Obstruction/Obesity', '1', '2.9.1 LEMON', 38, 'Add Your Comments...'),
(1250, 466565, 103, '', 1, '', 'NYHA Grade 2', '1', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 38, ''),
(1251, 466565, 103, '', 1, '', 'Moderate Restriction or Obstruction', '2', '3.2 Respiratory System (Pulmonary Function Test)', 38, ''),
(1252, 466565, 103, '', 1, '', 'EGFR 60 - 89', '1', '3.3 RENAL ', 38, ''),
(1253, 466565, 103, '', 1, '', '30 - 40', '2', '3.4 Respiratory Rate', 38, ''),
(1254, 466565, 103, '', 1, '', '92 - 100 with 2 to 4L O2', '1', '3.5 SPO2', 38, ''),
(1255, 466565, 103, '', 1, '', 'Optimal (SPB<120 and DPB<80)', '0', '3.6 Blood Pressure', 38, ''),
(1256, 466565, 103, '', 1, '', '6 - 8 and >20', '3', '3.7 Hemoglobin', 38, ''),
(1257, 466565, 103, '', 1, '', ' 120 - 140', '2', '3.8 Heart Rate', 38, ''),
(1258, 466565, 103, '', 1, '', '20 - 25', '1', '3.9 Breath Holding', 38, 'Add Your Comments...'),
(1259, 0, 101, '', 1, '', 'Adult', '1', '1. Age', 48, ''),
(1260, 0, 101, '', 1, '', '18.5 - 24.9', '0', '2. BMI', 48, ''),
(1261, 0, 101, '', 1, '', 'High Risk (5 - 8)', '2', '3. Stop Bang Score', 48, ''),
(1262, 0, 101, '', 1, '', 'Alcoholic', '1', '4. Personal History', 48, ''),
(1263, 0, 101, '', 1, '', '1', '1', '5. No of Previous Surgeries Under Anesthesia', 48, ''),
(1264, 0, 101, '', 1, '', 'NIL', '0', '6. Comorbidities', 48, ''),
(1265, 0, 101, '', 1, '', 'NIL', '0', '7. Allergy History ', 48, ''),
(1266, 0, 101, '', 1, '', 'A Awake', '0', '8. Mental Status', 48, ''),
(1267, 0, 101, '', 1, '', 'Major', '3', '9. Types of Surgery', 48, 'Add Your Comments...'),
(1268, 0, 102, '', 1, '', '>3 Fingers', '0', '2.1 Inter Incisor Gap (IIG)', 48, ''),
(1269, 0, 102, '', 1, '', '1', '0', '2.2 Modified Mallam Patti Scale (MMP)', 48, ''),
(1270, 0, 102, '', 1, '', '>4 Fingers Wide', '0', '2.3 Thyromental Distance', 48, ''),
(1271, 0, 102, '', 1, '', 'Severe Restriction', '3', '2.4 Neck Movement', 48, ''),
(1272, 0, 102, '', 1, '', 'Class 3', '2', '2.5 Upper Lip Bite Test', 48, ''),
(1273, 0, 102, '', 1, '', 'Snoring', '1', '2.6 BONES', 48, ''),
(1274, 0, 102, '', 1, '', 'Snoring/Stiff Lungs', '1', '2.7 MOANS', 48, ''),
(1275, 0, 102, '', 1, '', 'Stiff Lungs', '1', '2.8 RODS', 48, ''),
(1276, 0, 102, '', 1, '', 'Tumor', '1', '2.9 SHORT', 48, ''),
(1277, 0, 102, '', 1, '', 'Neck Mobility', '1', '2.9.1 LEMON', 48, 'Add Your Comments...'),
(1278, 0, 103, '', 1, '', 'NYHA Grade 4', '1', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 48, ''),
(1279, 0, 103, '', 1, '', 'Severe Restriction or Obstruction', '3', '3.2 Respiratory System (Pulmonary Function Test)', 48, ''),
(1280, 0, 103, '', 1, '', 'EGFR <15', '5', '3.3 RENAL ', 48, ''),
(1281, 0, 103, '', 1, '', '>40', '3', '3.4 Respiratory Rate', 48, ''),
(1282, 0, 103, '', 1, '', '92 - 100 with Ventilatory Support', '3', '3.5 SPO2', 48, ''),
(1283, 0, 103, '', 1, '', 'Grade 3 Hypertension (SPB > 180 and/or DPB >180)', '4', '3.6 Blood Pressure', 48, ''),
(1284, 0, 103, '', 1, '', '<6', '4', '3.7 Hemoglobin', 48, ''),
(1285, 0, 103, '', 1, '', '>160', '4', '3.8 Heart Rate', 48, ''),
(1286, 0, 103, '', 1, '', '<10', '3', '3.9 Breath Holding', 48, 'Add Your Comments...'),
(1287, 0, 104, '', 2, '', 'More than 30', '3', '4.1 Peak Airways Pressure', 12, ''),
(1288, 0, 104, '', 2, '', 'Anuria', '3', '4.2 Urine Output', 12, ''),
(1289, 0, 104, '', 2, '', '>2000ML', '4', '4.3 Blood Loss', 12, ''),
(1290, 0, 104, '', 2, '', 'NO', '2', '4.4 Blood Transfusion', 12, ''),
(1291, 0, 104, '', 2, '', 'NIL', '0', '4.5 Need For Inotropes', 12, ''),
(1292, 0, 104, '', 2, '', 'Given Within 1HR', '0', '4.6 Antibiotic', 12, 'Add Your Comments...'),
(1293, 0, 105, '', 3, '', 'NIL', '0', '5.1 Oxygen Requirements', 2, ''),
(1294, 0, 105, '', 3, '', 'ICU', '2', '5.2 ICU/WARD', 2, ''),
(1295, 0, 105, '', 3, '', '60 - 100', '0', '5.3 Heart Rate', 2, ''),
(1296, 0, 105, '', 3, '', '12 - 24', '0', '5.4 Respiratory Rate', 2, ''),
(1297, 0, 105, '', 3, '', '92 - 100 at RA', '0', '5.5 SPO2', 2, ''),
(1298, 0, 105, '', 3, '', 'Optimal (SPB<120 and DPB<80)', '0', '5.6 Blood Pressure', 2, ''),
(1299, 0, 105, '', 3, '', '12 - 16 mg/dl.', '0', '5.7 Hemoglobin', 2, ''),
(1300, 0, 105, '', 3, '', 'Score 1', '0', '5.8 Modified Ramsay Sedation Score', 2, ''),
(1301, 0, 105, '', 3, '', '0 - 2', '0', '5.9 Vas Score', 2, ''),
(1302, 0, 105, '', 3, '', 'NIL', '0', '5.9.1 PONV', 2, ''),
(1303, 0, 105, '', 3, '', '0(NIL)', '0', '5.9.2 Shivering Scale', 2, 'Add Your Comments...'),
(1304, 10090, 101, '', 1, '', 'Adult', '1', '1. Age', 62, ''),
(1305, 10090, 101, '', 1, '', '>=40', '4', '2. BMI', 62, ''),
(1306, 10090, 101, '', 1, '', 'Low Risk (0 - 2)', '0', '3. Stop Bang Score', 62, ''),
(1307, 10090, 101, '', 1, '', 'Both', '2', '4. Personal History', 62, ''),
(1308, 10090, 101, '', 1, '', '>2', '3', '5. No of Previous Surgeries Under Anesthesia', 62, ''),
(1309, 10090, 101, '', 1, '', 'Hypo/Hyperthyroidism', '1', '6. Comorbidities', 62, ''),
(1310, 10090, 101, '', 1, '', 'Allergy to Food', '1', '7. Allergy History ', 62, ''),
(1311, 10090, 101, '', 1, '', 'U Unconscious', '3', '8. Mental Status', 62, ''),
(1312, 10090, 101, '', 1, '', 'Minor', '1', '9. Types of Surgery', 62, 'Add Your Comments...'),
(1313, 10090, 102, '', 1, '', '<2Fingers', '2', '2.1 Inter Incisor Gap (IIG)', 62, ''),
(1314, 10090, 102, '', 1, '', '3 And 4', '2', '2.2 Modified Mallam Patti Scale (MMP)', 62, ''),
(1315, 10090, 102, '', 1, '', '<3 Fingers wide', '2', '2.3 Thyromental Distance', 62, ''),
(1316, 10090, 102, '', 1, '', 'Severe Restriction', '3', '2.4 Neck Movement', 62, ''),
(1317, 10090, 102, '', 1, '', 'Class 3', '2', '2.5 Upper Lip Bite Test', 62, ''),
(1318, 10090, 102, '', 1, '', 'Snoring', '1', '2.6 BONES', 62, ''),
(1319, 10090, 102, '', 1, '', 'Snoring/Stiff Lungs', '1', '2.7 MOANS', 62, ''),
(1320, 10090, 102, '', 1, '', 'Stiff Lungs', '1', '2.8 RODS', 62, ''),
(1321, 10090, 102, '', 1, '', 'Tumor', '1', '2.9 SHORT', 62, ''),
(1322, 10090, 102, '', 1, '', 'Neck Mobility', '1', '2.9.1 LEMON', 62, 'Add Your Comments...'),
(1323, 10090, 103, '', 1, '', 'NYHA Grade 4', '1', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 62, ''),
(1324, 10090, 103, '', 1, '', 'Severe Restriction or Obstruction', '3', '3.2 Respiratory System (Pulmonary Function Test)', 62, ''),
(1325, 10090, 103, '', 1, '', 'EGFR <15', '5', '3.3 RENAL ', 62, ''),
(1326, 10090, 103, '', 1, '', '>40', '3', '3.4 Respiratory Rate', 62, ''),
(1327, 10090, 103, '', 1, '', '92 - 100 with Ventilatory Support', '3', '3.5 SPO2', 62, ''),
(1328, 10090, 103, '', 1, '', 'Grade 3 Hypertension (SPB > 180 and/or DPB >180)', '4', '3.6 Blood Pressure', 62, ''),
(1329, 10090, 103, '', 1, '', '<6', '4', '3.7 Hemoglobin', 62, ''),
(1330, 10090, 103, '', 1, '', '>160', '4', '3.8 Heart Rate', 62, ''),
(1331, 10090, 103, '', 1, '', '<10', '3', '3.9 Breath Holding', 62, 'Add Your Comments...'),
(1332, 10090, 104, '', 2, '', 'More than 30', '3', '4.1 Peak Airways Pressure', 7, ''),
(1333, 10090, 104, '', 2, '', 'Anuria', '3', '4.2 Urine Output', 7, ''),
(1334, 10090, 104, '', 2, '', '<250ML', '0', '4.3 Blood Loss', 7, ''),
(1335, 10090, 104, '', 2, '', 'Yes', '1', '4.4 Blood Transfusion', 7, ''),
(1336, 10090, 104, '', 2, '', 'NIL', '0', '4.5 Need For Inotropes', 7, ''),
(1337, 10090, 104, '', 2, '', 'Given Within 1HR', '0', '4.6 Antibiotic', 7, 'Add Your Comments...'),
(1338, 10090, 104, '', 2, '', 'More than 30', '3', '4.1 Peak Airways Pressure', 7, ''),
(1339, 10090, 104, '', 2, '', 'Anuria', '3', '4.2 Urine Output', 7, ''),
(1340, 10090, 104, '', 2, '', '<250ML', '0', '4.3 Blood Loss', 7, ''),
(1341, 10090, 104, '', 2, '', 'Yes', '1', '4.4 Blood Transfusion', 7, ''),
(1342, 10090, 104, '', 2, '', 'NIL', '0', '4.5 Need For Inotropes', 7, ''),
(1343, 10090, 104, '', 2, '', 'Given Within 1HR', '0', '4.6 Antibiotic', 7, 'Add Your Comments...'),
(1344, 10090, 105, '', 3, '', 'Need For Ventilator', '3', '5.1 Oxygen Requirements', 24, ''),
(1345, 10090, 105, '', 3, '', 'WARD', '1', '5.2 ICU/WARD', 24, ''),
(1346, 10090, 105, '', 3, '', '>160', '4', '5.3 Heart Rate', 24, ''),
(1347, 10090, 105, '', 3, '', '>40', '3', '5.4 Respiratory Rate', 24, ''),
(1348, 10090, 105, '', 3, '', '92 - 100 at RA', '0', '5.5 SPO2', 24, ''),
(1349, 10090, 105, '', 3, '', 'Optimal (SPB<120 and DPB<80)', '0', '5.6 Blood Pressure', 24, ''),
(1350, 10090, 105, '', 3, '', '12 - 16 mg/dl.', '0', '5.7 Hemoglobin', 24, ''),
(1351, 10090, 105, '', 3, '', 'Score 5 and 6', '4', '5.8 Modified Ramsay Sedation Score', 24, ''),
(1352, 10090, 105, '', 3, '', '8 - 10', '4', '5.9 Vas Score', 24, ''),
(1353, 10090, 105, '', 3, '', 'Severe', '2', '5.9.1 PONV', 24, ''),
(1354, 10090, 105, '', 3, '', '3(Severe)', '3', '5.9.2 Shivering Scale', 24, 'Add Your Comments...'),
(1355, 7777, 101, '', 1, '', 'Adult', '1', '1. Age', 24, ''),
(1356, 7777, 101, '', 1, '', '18.5 - 24.9', '0', '2. BMI', 24, ''),
(1357, 7777, 101, '', 1, '', 'Low Risk (0 - 2)', '0', '3. Stop Bang Score', 24, ''),
(1358, 7777, 101, '', 1, '', 'Alcoholic', '1', '4. Personal History', 24, ''),
(1359, 7777, 101, '', 1, '', '1', '1', '5. No of Previous Surgeries Under Anesthesia', 24, ''),
(1360, 7777, 101, '', 1, '', 'NIL', '0', '6. Comorbidities', 24, ''),
(1361, 7777, 101, '', 1, '', 'Allergy to Drugs', '1', '7. Allergy History ', 24, ''),
(1362, 7777, 101, '', 1, '', 'P Pain', '2', '8. Mental Status', 24, ''),
(1363, 7777, 101, '', 1, '', 'Minor', '1', '9. Types of Surgery', 24, 'Add Your Comments...'),
(1364, 7777, 102, '', 1, '', '<2Fingers', '2', '2.1 Inter Incisor Gap (IIG)', 24, ''),
(1365, 7777, 102, '', 1, '', '3 And 4', '2', '2.2 Modified Mallam Patti Scale (MMP)', 24, ''),
(1366, 7777, 102, '', 1, '', '<3 Fingers wide', '2', '2.3 Thyromental Distance', 24, ''),
(1367, 7777, 102, '', 1, '', 'Severe Restriction', '3', '2.4 Neck Movement', 24, ''),
(1368, 7777, 102, '', 1, '', 'Class 2', '1', '2.5 Upper Lip Bite Test', 24, ''),
(1369, 7777, 102, '', 1, '', 'Beard ', '1', '2.6 BONES', 24, ''),
(1370, 7777, 102, '', 1, '', 'Mask Seal Difficulty', '1', '2.7 MOANS', 24, ''),
(1371, 7777, 102, '', 1, '', 'Obstruction', '1', '2.8 RODS', 24, ''),
(1372, 7777, 102, '', 1, '', 'Surgery or Airways Obstruction', '1', '2.9 SHORT', 24, ''),
(1373, 7777, 102, '', 1, '', 'Look Externally', '1', '2.9.1 LEMON', 24, 'Add Your Comments...'),
(1374, 7777, 103, '', 1, '', 'NIL ', '1', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 24, ''),
(1375, 7777, 103, '', 1, '', 'No Restriction', '0', '3.2 Respiratory System (Pulmonary Function Test)', 24, ''),
(1376, 7777, 103, '', 1, '', 'EGFR 60 - 89', '1', '3.3 RENAL ', 24, ''),
(1377, 7777, 103, '', 1, '', '12 - 24', '0', '3.4 Respiratory Rate', 24, ''),
(1378, 7777, 103, '', 1, '', '92 - 100 at RA', '0', '3.5 SPO2', 24, ''),
(1379, 7777, 103, '', 1, '', 'Optimal (SPB<120 and DPB<80)', '0', '3.6 Blood Pressure', 24, ''),
(1380, 7777, 103, '', 1, '', '12 - 16 mg/dl.', '0', '3.7 Hemoglobin', 24, ''),
(1381, 7777, 103, '', 1, '', '60 - 100', '0', '3.8 Heart Rate', 24, ''),
(1382, 7777, 103, '', 1, '', '>25', '0', '3.9 Breath Holding', 24, 'Add Your Comments...'),
(1383, 7777, 104, '', 2, '', '10 - 20', '0', '4.1 Peak Airways Pressure', 1, ''),
(1384, 7777, 104, '', 2, '', '1Ml/kg/HR', '0', '4.2 Urine Output', 1, ''),
(1385, 7777, 104, '', 2, '', '<250ML', '0', '4.3 Blood Loss', 1, ''),
(1386, 7777, 104, '', 2, '', 'Yes', '1', '4.4 Blood Transfusion', 1, ''),
(1387, 7777, 104, '', 2, '', 'NIL', '0', '4.5 Need For Inotropes', 1, ''),
(1388, 7777, 104, '', 2, '', 'Given Within 1HR', '0', '4.6 Antibiotic', 1, 'Add Your Comments...'),
(1389, 7777, 105, '', 3, '', 'Need For Ventilator', '3', '5.1 Oxygen Requirements', 4, ''),
(1390, 7777, 105, '', 3, '', 'WARD', '1', '5.2 ICU/WARD', 4, ''),
(1391, 7777, 105, '', 3, '', '60 - 100', '0', '5.3 Heart Rate', 4, ''),
(1392, 7777, 105, '', 3, '', '12 - 24', '0', '5.4 Respiratory Rate', 4, ''),
(1393, 7777, 105, '', 3, '', '92 - 100 at RA', '0', '5.5 SPO2', 4, ''),
(1394, 7777, 105, '', 3, '', 'Optimal (SPB<120 and DPB<80)', '0', '5.6 Blood Pressure', 4, ''),
(1395, 7777, 105, '', 3, '', '12 - 16 mg/dl.', '0', '5.7 Hemoglobin', 4, ''),
(1396, 7777, 105, '', 3, '', 'Score 1', '0', '5.8 Modified Ramsay Sedation Score', 4, ''),
(1397, 7777, 105, '', 3, '', '0 - 2', '0', '5.9 Vas Score', 4, ''),
(1398, 7777, 105, '', 3, '', 'NIL', '0', '5.9.1 PONV', 4, ''),
(1399, 7777, 105, '', 3, '', '0(NIL)', '0', '5.9.2 Shivering Scale', 4, 'Add Your Comments...'),
(1400, 1232, 101, '', 1, '', 'Adult', '1', '1. Age', 45, ''),
(1401, 1232, 101, '', 1, '', '>=40', '4', '2. BMI', 45, ''),
(1402, 1232, 101, '', 1, '', 'Low Risk (0 - 2)', '0', '3. Stop Bang Score', 45, ''),
(1403, 1232, 101, '', 1, '', 'Both', '2', '4. Personal History', 45, ''),
(1404, 1232, 101, '', 1, '', '>2', '3', '5. No of Previous Surgeries Under Anesthesia', 45, ''),
(1405, 1232, 101, '', 1, '', 'Hypo/Hyperthyroidism', '1', '6. Comorbidities', 45, ''),
(1406, 1232, 101, '', 1, '', 'Allergy to Food', '1', '7. Allergy History ', 45, ''),
(1407, 1232, 101, '', 1, '', 'U Unconscious', '3', '8. Mental Status', 45, ''),
(1408, 1232, 101, '', 1, '', 'Minor', '1', '9. Types of Surgery', 45, 'Add Your Comments...'),
(1409, 1232, 102, '', 1, '', '<2Fingers', '2', '2.1 Inter Incisor Gap (IIG)', 45, ''),
(1410, 1232, 102, '', 1, '', '3 And 4', '2', '2.2 Modified Mallam Patti Scale (MMP)', 45, ''),
(1411, 1232, 102, '', 1, '', '<3 Fingers wide', '2', '2.3 Thyromental Distance', 45, ''),
(1412, 1232, 102, '', 1, '', 'Severe Restriction', '3', '2.4 Neck Movement', 45, ''),
(1413, 1232, 102, '', 1, '', 'Class 3', '2', '2.5 Upper Lip Bite Test', 45, ''),
(1414, 1232, 102, '', 1, '', 'Snoring', '1', '2.6 BONES', 45, ''),
(1415, 1232, 102, '', 1, '', 'Snoring/Stiff Lungs', '1', '2.7 MOANS', 45, ''),
(1416, 1232, 102, '', 1, '', 'Stiff Lungs', '1', '2.8 RODS', 45, ''),
(1417, 1232, 102, '', 1, '', 'Tumor', '1', '2.9 SHORT', 45, ''),
(1418, 1232, 102, '', 1, '', 'Obstruction/Obesity', '1', '2.9.1 LEMON', 45, 'Add Your Comments...'),
(1419, 1232, 103, '', 1, '', 'NYHA Grade 4', '1', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 45, ''),
(1420, 1232, 103, '', 1, '', 'Severe Restriction or Obstruction', '3', '3.2 Respiratory System (Pulmonary Function Test)', 45, ''),
(1421, 1232, 103, '', 1, '', 'EGFR <15', '5', '3.3 RENAL ', 45, ''),
(1422, 1232, 103, '', 1, '', '>40', '3', '3.4 Respiratory Rate', 45, ''),
(1423, 1232, 103, '', 1, '', '92 - 100 at RA', '0', '3.5 SPO2', 45, ''),
(1424, 1232, 103, '', 1, '', 'Optimal (SPB<120 and DPB<80)', '0', '3.6 Blood Pressure', 45, ''),
(1425, 1232, 103, '', 1, '', '10 - 12 and 16 - 18', '1', '3.7 Hemoglobin', 45, ''),
(1426, 1232, 103, '', 1, '', '60 - 100', '0', '3.8 Heart Rate', 45, ''),
(1427, 1232, 103, '', 1, '', '>25', '0', '3.9 Breath Holding', 45, 'Add Your Comments...'),
(1428, 1232, 104, '', 2, '', 'More than 30', '3', '4.1 Peak Airways Pressure', 8, ''),
(1429, 1232, 104, '', 2, '', 'Anuria', '3', '4.2 Urine Output', 8, ''),
(1430, 1232, 104, '', 2, '', '250 - 500ML', '1', '4.3 Blood Loss', 8, ''),
(1431, 1232, 104, '', 2, '', 'Yes', '1', '4.4 Blood Transfusion', 8, ''),
(1432, 1232, 104, '', 2, '', 'NIL', '0', '4.5 Need For Inotropes', 8, ''),
(1433, 1232, 104, '', 2, '', 'Given Within 1HR', '0', '4.6 Antibiotic', 8, 'Add Your Comments...'),
(1434, 1232, 105, '', 3, '', 'Need For Ventilator', '3', '5.1 Oxygen Requirements', 23, ''),
(1435, 1232, 105, '', 3, '', 'WARD', '1', '5.2 ICU/WARD', 23, ''),
(1436, 1232, 105, '', 3, '', '>160', '4', '5.3 Heart Rate', 23, ''),
(1437, 1232, 105, '', 3, '', '>40', '3', '5.4 Respiratory Rate', 23, ''),
(1438, 1232, 105, '', 3, '', '92 - 100 with Ventilatory Support', '3', '5.5 SPO2', 23, ''),
(1439, 1232, 105, '', 3, '', 'Optimal (SPB<120 and DPB<80)', '0', '5.6 Blood Pressure', 23, ''),
(1440, 1232, 105, '', 3, '', '12 - 16 mg/dl.', '0', '5.7 Hemoglobin', 23, ''),
(1441, 1232, 105, '', 3, '', 'Score 1', '0', '5.8 Modified Ramsay Sedation Score', 23, ''),
(1442, 1232, 105, '', 3, '', '8 - 10', '4', '5.9 Vas Score', 23, ''),
(1443, 1232, 105, '', 3, '', 'Severe', '2', '5.9.1 PONV', 23, ''),
(1444, 1232, 105, '', 3, '', '3(Severe)', '3', '5.9.2 Shivering Scale', 23, 'Add Your Comments...'),
(1445, 1234567, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1446, 1234567, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1447, 1234567, 101, '', 1, '', 'we', '3', '1 Personal History', 9, ''),
(1448, 1234567, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1449, 1234567, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1450, 1234567, 101, '', 1, '', 'we', '3', '1 Personal History', 9, ''),
(1451, 1234567, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1452, 1234567, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1453, 1234567, 101, '', 1, '', 'we', '3', '1 Personal History', 9, ''),
(1454, 1234567, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1455, 1234567, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1456, 1234567, 101, '', 1, '', 'we', '3', '1 Personal History', 9, ''),
(1457, 1234567, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1458, 1234567, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1459, 1234567, 101, '', 1, '', 'we', '3', '1 Personal History', 9, ''),
(1460, 1234567, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1461, 1234567, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1462, 1234567, 101, '', 1, '', 'we', '3', '1 Personal History', 9, ''),
(1463, 1234567, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1464, 1234567, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1465, 1234567, 101, '', 1, '', 'we', '3', '1 Personal History', 9, ''),
(1466, 98765, 101, '', 1, '', 'Both', '3', '1 Personal History', 9, ''),
(1467, 98765, 101, '', 1, '', 'age', '3', '1 Personal History', 9, ''),
(1468, 98765, 101, '', 1, '', 'we', '3', '1 Personal History', 9, '');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_login`
--

CREATE TABLE `doctor_login` (
  `s_no` int(11) NOT NULL,
  `doctor_id` varchar(266) NOT NULL,
  `password` varchar(266) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_login`
--

INSERT INTO `doctor_login` (`s_no`, `doctor_id`, `password`) VALUES
(1, 'SMCD101', 'welcome');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_profile`
--

CREATE TABLE `doctor_profile` (
  `s_no` int(20) NOT NULL,
  `doctor_id` varchar(266) NOT NULL,
  `Name` varchar(266) NOT NULL,
  `Mobile_no` varchar(20) NOT NULL,
  `Email_id` varchar(266) NOT NULL,
  `Address` varchar(266) NOT NULL,
  `Designation` varchar(266) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_profile`
--

INSERT INTO `doctor_profile` (`s_no`, `doctor_id`, `Name`, `Mobile_no`, `Email_id`, `Address`, `Designation`, `image`) VALUES
(1, 'SMCD101', 'pringless', '1234567890', 'kirubadoctor1234@gmail.com', 'anna nagar1', 'Doctor@mbbs', 'image/SMCD101.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `s_no` int(50) NOT NULL,
  `Patient_id` int(100) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`s_no`, `Patient_id`, `image`) VALUES
(1, 12345, 'image/12345.jpg'),
(2, 101, 'image/101.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mainquestions`
--

CREATE TABLE `mainquestions` (
  `main_question_id` int(11) NOT NULL,
  `main_question_text` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mainquestions`
--

INSERT INTO `mainquestions` (`main_question_id`, `main_question_text`) VALUES
(1, 'Pre-Operative'),
(2, 'Intra Operative'),
(3, 'Post Operative');

-- --------------------------------------------------------

--
-- Table structure for table `patient_total_score`
--

CREATE TABLE `patient_total_score` (
  `s_no` int(255) NOT NULL,
  `Patient_id` varchar(255) NOT NULL,
  `Pre_Operative` int(11) DEFAULT 0,
  `Intra_Operative` int(11) DEFAULT 0,
  `Post_Operative` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_total_score`
--

INSERT INTO `patient_total_score` (`s_no`, `Patient_id`, `Pre_Operative`, `Intra_Operative`, `Post_Operative`) VALUES
(0, '1234567', 9, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `main_question_id` int(19) NOT NULL,
  `subdivision_id` int(11) NOT NULL,
  `subdivision_text` varchar(50) NOT NULL,
  `main_question_text` varchar(50) NOT NULL,
  `question_id` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `option_1` varchar(255) DEFAULT NULL,
  `option_2` varchar(255) DEFAULT NULL,
  `option_3` varchar(255) DEFAULT NULL,
  `option_4` varchar(255) DEFAULT NULL,
  `option_5` varchar(255) DEFAULT NULL,
  `option_6` varchar(255) DEFAULT NULL,
  `Score_Values1` int(11) DEFAULT NULL,
  `Score_Values2` int(11) NOT NULL,
  `Score_Values3` int(11) NOT NULL,
  `Score_Values4` int(11) NOT NULL,
  `Score_Values5` int(11) NOT NULL,
  `Score_Values6` int(11) NOT NULL,
  `add_comment_box` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`main_question_id`, `subdivision_id`, `subdivision_text`, `main_question_text`, `question_id`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `option_5`, `option_6`, `Score_Values1`, `Score_Values2`, `Score_Values3`, `Score_Values4`, `Score_Values5`, `Score_Values6`, `add_comment_box`) VALUES
(1, 101, 'History & Examination', 'Pre-Operative', '1', '1. Age', 'Pediatric/Elderly', 'Adult', '', '', '', '', 2, 1, 0, 0, 0, 0, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '2', '2. BMI', '18.5 - 24.9', '<18.5', '25 - 29.9', '30 - 34.9', '35 - 39.9', '>=40', 0, 1, 1, 2, 3, 4, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '3', '3. Stop Bang Score', 'High Risk (5 - 8)', 'Intermediate Risk (3 - 4)', 'Low Risk (0 - 2)', '', '', '', 2, 1, 0, 0, 0, 0, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '4', '4. Personal History', 'Alcoholic', 'Smoker', 'Both', '', '', '', 1, 1, 2, 0, 0, 0, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '5', '5. No of Previous Surgeries Under Anesthesia', '1', '2', '>2', '', '', '', 1, 2, 3, 0, 0, 0, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '6', '6. Comorbidities', 'NIL', 'Diabetic', 'Hypertension', 'Hypo/Hyperthyroidism', '', '', 0, 1, 1, 1, 0, 0, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '7', '7. Allergy History ', 'NIL', 'Allergy to Drugs', 'Allergy to Food', '', '', '', 0, 1, 1, 0, 0, 0, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '8', '8. Mental Status', 'A Awake', 'V Verbal', 'P Pain', 'U Unconscious', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(1, 101, 'History & Examination', 'Pre-Operative', '9', '9. Types of Surgery', 'Major', 'Intermediate', 'Minor', '', '', '', 3, 2, 1, 0, 0, 0, 'Yes'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '10', '2.1 Inter Incisor Gap (IIG)', '>3 Fingers', '2 -3 Fingers', '<2Fingers', '', '', '', 0, 1, 2, 0, 0, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '11', '2.2 Modified Mallam Patti Scale (MMP)', '1', '2', '3 And 4', '', '', '', 0, 1, 2, 0, 0, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '12', '2.3 Thyromental Distance', '>4 Fingers Wide', '4 - 3 Fingers Wide', '<3 Fingers wide', '', '', '', 0, 1, 2, 0, 0, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '13', '2.4 Neck Movement', 'No Restriction', 'Mild Restriction', 'Moderate Restriction', 'Severe Restriction', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '14', '2.5 Upper Lip Bite Test', 'Class 1', 'Class 2', 'Class 3', '', '', '', 0, 1, 2, 0, 0, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '15', '2.6 BONES', 'Beard ', 'Obesity', 'No Teeth/Edentulous', 'Elderly', 'Snoring', '', 1, 1, 1, 1, 1, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '16', '2.7 MOANS', 'Mask Seal Difficulty', 'Obesity', 'Age', 'No Teeth', 'Snoring/Stiff Lungs', '', 1, 1, 1, 1, 1, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '17', '2.8 RODS', 'Restricted Mouth Openning', 'Obstruction', 'Disrupted/Distorted Airways', 'Stiff Lungs', '', '', 1, 1, 1, 1, 0, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '18', '2.9 SHORT', 'Surgery or Airways Obstruction', 'Hematoma', 'Obesity', 'Radiation Distortion', 'Tumor', '', 1, 1, 1, 1, 1, 0, 'No'),
(1, 102, 'Airways Assessment', 'Pre-Operative', '19', '2.9.1 LEMON', 'Look Externally', 'Evaluate Using 3:3:2 Rule', 'Mallam Patti Scale ', 'Obstruction/Obesity', 'Neck Mobility', '', 1, 1, 1, 1, 1, 0, 'Yes'),
(1, 103, 'Systemic', 'Pre-Operative', '20', '3.1 Cardiovascular System(K/C/O Any Cardiac illness)', 'NIL ', 'NYHA Grade 1', 'NYHA Grade 2', 'NYHA Grade 3', 'NYHA Grade 4', '', 1, 1, 1, 1, 1, 0, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '21', '3.2 Respiratory System (Pulmonary Function Test)', 'No Restriction', 'Mild Restriction or Obstruction', 'Moderate Restriction or Obstruction', 'Severe Restriction or Obstruction', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '22', '3.3 RENAL ', 'EGFR >90', 'EGFR 60 - 89', 'EGFR 45 - 59', 'EGFR 30 - 44', 'EGFR 15 - 29', 'EGFR <15', 0, 1, 2, 3, 4, 5, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '23', '3.4 Respiratory Rate', '12 - 24', '<12 and 24 - 30', '30 - 40', '>40', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '24', '3.5 SPO2', '92 - 100 at RA', '92 - 100 with 2 to 4L O2', '92 - 100 with 4 to 10L O2', '92 - 100 with Ventilatory Support', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '25', '3.6 Blood Pressure', 'Optimal (SPB<120 and DPB<80)', 'High Normal (SPB 120 - 129 and DPB 80 - 84)', 'Grade 1 Hypertension (SPB 130 - 139 and/or DPB 85 - 89)', 'Grade 2 Hypertension (SPB 140 - 159 and/or DPB 90 - 99)', 'Grade 3 Hypertension (SPB > 180 and/or DPB >180)', '', 0, 1, 2, 3, 4, 0, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '26', '3.7 Hemoglobin', '12 - 16 mg/dl.', '10 - 12 and 16 - 18', '8 - 10 and 18 - 20 ', '6 - 8 and >20', '<6', '', 0, 1, 2, 3, 4, 0, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '27', '3.8 Heart Rate', '60 - 100', '40 - 60 and 100 - 120', ' 120 - 140', ' 140 - 160', '>160', '', 0, 1, 2, 3, 4, 0, 'No'),
(1, 103, 'Systemic', 'Pre-Operative', '28', '3.9 Breath Holding', '>25', '20 - 25', '10 - 20', '<10', '', '', 0, 1, 2, 3, 0, 0, 'Yes'),
(2, 104, '', 'Intra-Operative', '29', '4.1 Peak Airways Pressure', '10 - 20', '20 - 25', '25 - 30', 'More than 30', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(2, 104, '', 'Intra-Operative', '30', '4.2 Urine Output', '1Ml/kg/HR', '0.05Ml/kg/HR', '<0.05Ml/kg/HR', 'Anuria', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(2, 104, '', 'Intra-Operative', '31', '4.3 Blood Loss', '<250ML', '250 - 500ML', '500 - 1000ML', '1000 - 2000ML', '>2000ML', '', 0, 1, 2, 3, 4, 0, 'No'),
(2, 104, '', 'Intra-Operative', '32', '4.4 Blood Transfusion', 'Yes', 'NO', '', '', '', '', 1, 2, 0, 0, 0, 0, 'No'),
(2, 104, '', 'Intra-Operative', '33', '4.5 Need For Inotropes', 'NIL', '1 Inotropes (<5ML/HR)', '1 Inotropes (>5ML/HR)', '2 Inotropes', '3 Inotropes', '', 0, 1, 2, 3, 4, 0, 'No'),
(2, 104, '', 'Intra-Operative', '34', '4.6 Antibiotic', 'Given Within 1HR', 'Given Before 1HR', 'Not Given', '', '', '', 0, 1, 2, 0, 0, 0, 'Yes'),
(3, 105, '', 'Post-Operative', '35', '5.1 Oxygen Requirements', 'NIL', '<5 LO2', '5 - 15 LO2', 'Need For Ventilator', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(3, 105, '', 'Post-Operative', '36', '5.2 ICU/WARD', 'ICU', 'WARD', '', '', '', '', 2, 1, 0, 0, 0, 0, 'No'),
(3, 105, '', 'Post-Operative', '37', '5.3 Heart Rate', '60 - 100', '40 - 60 and 100 - 120', ' 120 - 140', ' 140 - 160', '>160', '', 0, 1, 2, 3, 4, 0, 'No'),
(3, 105, '', 'Post-Operative', '38', '5.4 Respiratory Rate', '12 - 24', '<12 and 24 - 30', '30 - 40', '>40', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(3, 105, '', 'Post-Operative', '39', '5.5 SPO2', '92 - 100 at RA', '92 - 100 with 2 to 4L O2', '92 - 100 with 4 to 10L O2', '92 - 100 with Ventilatory Support', '', '', 0, 1, 2, 3, 0, 0, 'No'),
(3, 105, '', 'Post-Operative', '40', '5.6 Blood Pressure', 'Optimal (SPB<120 and DPB<80)', 'High Normal (SPB 120 - 129 and DPB 80 - 84)', 'Grade 1 Hypertension (SPB 130 - 139 and/or DPB 85 - 89)', 'Grade 2 Hypertension (SPB 140 - 159 and/or DPB 90 - 99)', 'Grade 3 Hypertension (SPB > 180 and/or DPB >180)', '', 0, 1, 2, 3, 4, 0, 'No'),
(3, 105, '', 'Post-Operative', '41', '5.7 Hemoglobin', '12 - 16 mg/dl.', '10 - 12 and 16 - 18', '8 - 10 and 18 - 20 ', '6 - 8 and >20', '<6', '', 0, 1, 2, 3, 4, 0, 'No'),
(3, 105, '', 'Post-Operative', '42', '5.8 Modified Ramsay Sedation Score', 'Score 1', 'Score 2', 'Score 3', 'Score 4', 'Score 5 and 6', '', 0, 1, 2, 3, 4, 0, 'No'),
(3, 105, '', 'Post-Operative', '43', '5.9 Vas Score', '0 - 2', '3 - 4', '5', '6 - 7', '8 - 10', '', 0, 1, 2, 3, 4, 0, 'No'),
(3, 105, '', 'Post-Operative', '44', '5.9.1 PONV', 'NIL', 'Mild', 'Severe', '', '', '', 0, 1, 2, 0, 0, 0, 'No'),
(3, 105, '', 'Post-Operative', '45', '5.9.2 Shivering Scale', '0(NIL)', '1(Mild)', '2(Moderate)', '3(Severe)', '', '', 0, 1, 2, 3, 0, 0, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `score_category`
--

CREATE TABLE `score_category` (
  `s_no` int(255) NOT NULL,
  `main_question_id` int(100) NOT NULL,
  `main_question_text` varchar(255) NOT NULL,
  `category_option_1` varchar(255) NOT NULL,
  `category_option_2` varchar(255) NOT NULL,
  `category_option_3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `score_category`
--

INSERT INTO `score_category` (`s_no`, `main_question_id`, `main_question_text`, `category_option_1`, `category_option_2`, `category_option_3`) VALUES
(1, 1, 'Pre-Operative', '<25 Mild Risk', '25-48 Moderate Risk', '>48 Severe Risk'),
(2, 2, 'Intra Operative', '<6 Un Event Full', '6-12 Moderate Risk Surgery', '>12 High Risk Surgery'),
(3, 3, 'Post Operative', '<15 Very Good Out Come', '15-26 Moderate Out Come', '>26 Poor Out Come');

-- --------------------------------------------------------

--
-- Table structure for table `subdivisions`
--

CREATE TABLE `subdivisions` (
  `subdivision_id` int(11) NOT NULL,
  `main_question_id` int(11) DEFAULT NULL,
  `subdivision_text` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subdivisions`
--

INSERT INTO `subdivisions` (`subdivision_id`, `main_question_id`, `subdivision_text`) VALUES
(101, 1, 'History & Examination'),
(102, 1, 'Airways Assessment'),
(103, 1, 'Systemic'),
(104, 2, ''),
(105, 3, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addpatient`
--
ALTER TABLE `addpatient`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `doctor_login`
--
ALTER TABLE `doctor_login`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `doctor_profile`
--
ALTER TABLE `doctor_profile`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `mainquestions`
--
ALTER TABLE `mainquestions`
  ADD PRIMARY KEY (`main_question_id`);

--
-- Indexes for table `patient_total_score`
--
ALTER TABLE `patient_total_score`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`subdivision_id`,`question`);

--
-- Indexes for table `score_category`
--
ALTER TABLE `score_category`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `subdivisions`
--
ALTER TABLE `subdivisions`
  ADD PRIMARY KEY (`subdivision_id`),
  ADD KEY `main_division_id` (`main_question_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addpatient`
--
ALTER TABLE `addpatient`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1469;

--
-- AUTO_INCREMENT for table `doctor_login`
--
ALTER TABLE `doctor_login`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctor_profile`
--
ALTER TABLE `doctor_profile`
  MODIFY `s_no` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `score_category`
--
ALTER TABLE `score_category`
  MODIFY `s_no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `fk_questions_subdivision_id` FOREIGN KEY (`subdivision_id`) REFERENCES `subdivisions` (`subdivision_id`),
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`subdivision_id`) REFERENCES `subdivisions` (`subdivision_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
